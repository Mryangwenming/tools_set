## 1.安装gitlab-runner:  
* 添加镜像源: curl -L https://packages.gitlab.com/install/repositories/runner/gitlab-ci-multi-runner/script.deb.sh | sudo bash   
* 安装gitlab-runner,命令:  sudo apt-get install gitlab-runner  
## 2.注册gitlab-runner:
* 执行命令: sudo gitlab-runner register,接下来按照[图片](./register.jpeg)上的步骤进行注册.
* 1: #找到[图片](./gitlab-runner.png)中的gitlab服务器地址，也就是图片中标出来的url.  
* 2:#输入随机码.也就是上面图片中的token.  
* 3: #runner 服务器的描述.  
* 4: #runner打tag，在之后执行ci脚本可以通过tags选择runner.  
* 5: #一般选择flase,也可以在配置完之后修改.  
* 6: #一般选择true,也可以在配置完之后修改. 
* 7: #设置runner运行方式，使用本机的话输入shell，也可以选择其他  
* 当上面的注册操作完成之后,需要重启gitlab-runner,命令: sudo gitlab-runner restart  
* 怎样查看runner是否配置好,请参考[图片](./runner.jpeg)中的描述检查(备注：gitlab runner配置文件在/etc/gitlab-runner/config.toml).
## 3.使用gitlab-runner:
* 在项目的根目录下新建.gitlab-ci.yml文件(注:gitlab-runner会根据这个文件中的内容进行相应的操作)  
* .gitlab-ci.yml 文件中包含的主要字段及其说明详见[图片](./gitlab-ci-param.png):  
* 简单示例[gitlab-ci.yml](./gitlab-ci.yml),一般只进行编译操作的时候,简单示例可以作为模板,具体复杂功能可以参考链接: https://www.jianshu.com/p/29d75a2cda74  
* 当配置完.gitlab-ci.yml 文件之后需要一同推送到gitlab上,如果在.gitlab-ci.yml 文件的only字段中指定了分支的名称,那么只有当指定分支有新push的时候,才会触发ci运行.  
## 注意问题:
* 如果选用的是本机作为runner的话, 那么会在/home下创建一个gitlab-runner用户,.gitlab-ci.yml 文件中运行的脚本的操作,均是在这个用户的文件夹下进行.  
* 需要将gitlab-runner加入到root用户组,否则权限不足: usermod -g root gitlab-runner  
* 当添加gitlab中的ssh-key时,需要添加在/home/gitlab-runner 文件夹下面的ssh-key,所以在生成ssh-key时,路径应该选择/home/gitlab-runner/.ssh/id_rsa,然后将其配置到gitlab中.  
* 添加完之后还需要修改文件夹权限: 先将.ssh文件夹的权限设置为 755, 然后进入.ssh,设置id_rsa, id_rsa.pub 的权限为600, 将known_hosts(无需保留此文件)删除.  
* 然后打开/etc/ssh/ssh_config 文件, 找到#StrictHostKeyChecking ask去掉注释，并把ask改为no, 这样在第一次连接的时候就不会出现需要输入yes的提示了,也就可以直接进行操作了.
